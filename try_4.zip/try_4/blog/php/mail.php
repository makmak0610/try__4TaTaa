<?php


$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "service";

// Create a connection to the database
$conn = mysqli_connect($servername, $username, $password, $dbname);



$email = $_POST['email'];
$subject = "Email for confirmation of service Booking";

$message = "Your service is being confirmed";
$header = "From: nsmankr1@gmail.com";

mail($email,$subject,$message,$header);

?>