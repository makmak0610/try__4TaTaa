<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tata Motors</title>
    <link rel="icon" href="/static/tata.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="javascript" href="java.js>">
  </head>
  <Body >  
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                <a href="https://www.tatamotors.com/">
                    <img src="/static/motors-logo.jpg" height="90px" width="250px">
                </a>
                <ul class="nav justify-content-center">
                  <li class="nav-item" >
                    <a class="nav-link active" aria-current="page" href="https://www.tatamotors.com/about-us/"><span>About-us</span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/products/">Products</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/markets/">Markets</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/corporate-social-responsibility/">CSR</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/investors/">Investors</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/media/">Media</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/blog/">Blog</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" href="https://joinus.tatamotors.com/">Careers</a>
                 </li>
                 <li class="nav-item">
                    <a class="nav-link active" href="https://www.tatamotors.com/contact-us/">Contact-us</a>
                 </li>
                </ul>
                </div>
                    <!-- Image 2 -->
                    <a href="https://www.tata.com/" target = "_blank">
                    <img src="/static/Logo.png" height="90X" width="150px">
                </a>
            </div>
        </nav>
      
          <div class="container-fluid mx-8">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img src="/static/index1.jpg" class="d-block w-100" alt="..."  height="450px" width="100px">
              </div>
              <div class="carousel-item">
                <img src="/static/index2.jpg" class="d-block w-100" alt="..."  height="450px" width="100px">
              </div>
              <div class="carousel-item">
                <img src="/static/service1.jpg" class="d-block w-100" alt="..."  height="450px" width="100px">
              </div>
            </div>
          </div>
        </div>
        
     
 <div class = "container-fluid">
    <div class="p-3 mb-2 bg-primary text-white">
    <h3 style="text-align:center; color: whitesmoke">Services we offer</h3>
  
  <div class = "container-fluid my-4 mx-8">
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
              <div class="card h-200">
                <a href="service.php">
                <img src="/static/warrantyclaim.png" class="card-img-top" height="250" width="60"></a><hr>
                <div class="card-body">
                  <h5 class="card-title">Claim Warranty</h5>      
                  <p class="card-text">
                    Safeguard your peace of mind with our reliable warranty claim service. We've got you covered when unexpected issues arise with your purchased products. Our dedicated team streamlines the process, handling all paperwork and negotiations with manufacturers. Rest assured, we'll ensure a hassle-free experience, honoring your warranty to its fullest extent.
                  </p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <a href="service.php">
                <img src="/static/engineservicing.png" class="card-img-top" alt="..."></a><hr>
                <div class="card-body">
                  <h5 class="card-title">Engine work</h5>
                  <p class="card-text">Revitalize your vehicle's heart with our top-notch engine work service. Our skilled mechanics are experts in diagnosing and repairing engine issues, ensuring optimal performance. From tune-ups to major repairs, we use advanced techniques and high-quality parts to bring your engine back to life. Drive with confidence and power under the hood.</p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <a href="service.php">
                <img src="/static/carcleaning.png" class="card-img-top" alt="..."></a><hr>
                <div class="card-body">
                  <h5 class="card-title">Car Cleaning</h5>
                  <p class="card-text">Indulge your car in a luxurious spa-like experience with our premium car cleaning service. We pamper your vehicle inside out, from meticulous handwashing and waxing to thorough interior detailing. Our eco-friendly products and skilled team leave your car gleaming and smelling fresh, bringing back that showroom shine. Drive in style and comfort with our exceptional care.
                  </p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <a href="service.php">
                <img src="/static/bodyshop1.png" class="card-img-top" alt="..." height="200px" width="25px"></a><hr>
                <div class="card-body">
                  <h5 class="card-title">Denting and painting</h5>
                  <p class="card-text">Experience flawless automotive care with our expert denting and painting service. We pride ourselves on transforming your vehicle's appearance, making those dents disappear like magic. Our skilled team ensures precision in every paint job, giving your car a showroom-worthy finish. Trust us to revitalize your ride and leave it looking as good as new.</p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <a href="service.php">
                <img src="/static/wheel.jpg" class="card-img-top" height="200"></a><hr>
                <div class="card-body">
                  <h5 class="card-title">Wheel care</h5>
                  <p class="card-text">Revive your wheels' allure with our comprehensive wheel care service. Our experts handle everything from cleaning brake dust to repairing minor damages. Using specialized tools and premium products, we restore the original luster and protect against future wear. Drive confidently, knowing your wheels are in pristine condition, complementing your vehicle's overall aesthetics.
                  </p>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <a href="service.php">
                <img src="/static/generalservice.png" class="card-img-top"  height="200" width=" 50"></a><hr>
                <div class="card-body">
                  <h5 class="card-title">Genral Services</h5>
                  <p class="card-text">Experience a holistic approach to vehicle maintenance with our exceptional general care service. From routine check-ups to comprehensive inspections, our skilled technicians ensure every aspect of your car is in top condition. With meticulous attention to detail and genuine care, we keep your ride safe, efficient, and ready for any journey ahead.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr>
      
        <footer class="bd-footer py-0 py-md-0 mt-0 bg-body-secondary">
        <div class="container py-4 py-md-5 px-4 px-md-3 text-body-secondary">
          <div class="row">
            <div class="col-lg-3 mb-3">
              <a class="d-inline-flex align-items-center mb-2 text-body-emphasis text-decoration-none" href="/" aria-label="Bootstrap">
                <img src ="/static/fav.png" width="40" height="32" class="d-block me-2" viewBox="0 0 118 94" role="img"><title>About</title><path fill-rule="evenodd" clip-rule="evenodd" d="M24.509 0c-6.733 0-11.715 5.893-11.492 12.284.214 6.14-.064 14.092-2.066 20.577C8.943 39.365 5.547 43.485 0 44.014v5.972c5.547.529 8.943 4.649 10.951 11.153 2.002 6.485 2.28 14.437 2.066 20.577C12.794 88.106 17.776 94 24.51 94H93.5c6.733 0 11.714-5.893 11.491-12.284-.214-6.14.064-14.092 2.066-20.577 2.009-6.504 5.396-10.624 10.943-11.153v-5.972c-5.547-.529-8.934-4.649-10.943-11.153-2.002-6.484-2.28-14.437-2.066-20.577C105.214 5.894 100.233 0 93.5 0H24.508zM80 57.863C80 66.663 73.436 72 62.543 72H44a2 2 0 01-2-2V24a2 2 0 012-2h18.437c9.083 0 15.044 4.92 15.044 12.474 0 5.302-4.01 10.049-9.119 10.88v.277C75.317 46.394 80 51.21 80 57.863zM60.521 28.34H49.948v14.934h8.905c6.884 0 10.68-2.772 10.68-7.727 0-4.643-3.264-7.207-9.012-7.207zM49.948 49.2v16.458H60.91c7.167 0 10.964-2.876 10.964-8.281 0-5.406-3.903-8.178-11.425-8.178H49.948z" fill="currentColor"></path></svg>
                <span class="fs-5">About</span>
              </a>
              <ul class="list-unstyled small">
                <li class="mb-2">Tata Motors Limited, a USD 37 billion organisation, is a leading global automobile manufacturer with a portfolio that covers a wide range of cars, SUVs, buses, trucks, pickups and defence vehicles.</li>
                <li class="mb-2">Currently v5.3.0.</li>
              </ul>
            </div>
            <div class="col-6 col-lg-2 offset-lg-1 mb-3">
              <h5>Links</h5>
              <ul class="list-unstyled">
                <li class="mb-2"><a href="/">Home</a></li>
                <li class="mb-2"><a href="https://www.tatamotors.com/about-us/">About us</a></li>
                <li class="mb-2"><a href="https://www.tatamotors.com/markets/">Markets</a></li>
                <li class="mb-2"><a href="https://icons.getbootstrap.com/">Icons</a></li>
                <li class="mb-2"><a href="service.php">Services</a></li>
              </ul>
            </div>
            <div class="col-6 col-lg-2 mb-3">
              <h5>Socials</h5>
              <ul class="list-unstyled">
                <li class="mb-2"><a href="#"><img src="/static/whatsapp.png" height="30" width="30"></a></li>
                <li class="mb-2"><a href="#"><img src="/static/facebook.png" height="30" width="30"></a></li>
                <li class="mb-2"><a href="#"><img src="/static/instagram.jpg" height="30" width="30"></a></li>
                <li class="mb-2"><a href="#"><img src="/static/twitter.png" height="30" width="30"></a></li>
              </ul>
            </div>

            <div class="col-6 col-lg-2 mb-3">
              <h5>Contact Us</h5>
              <ul class="list-unstyled">
                <li class="mb-2">+91 9162531613,+91 7290019177</li><p></p>
                <li class="mb-2">mm1611@dseu.ac.in,sumsh30@gmail.com</li><p></p>
                <li class="mb-2">Trendsetters skills accesor Gurgaon,Harayana</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>


<style>
        .whatsapp_float{
          position: fixed;
          bottom: 40px;
          right: 20px;
        }
      </style>
      <div class="whatsapp_float">
        <a href="https://wa.me/919162531613" target="_blank">
          <img src="/static/whatsapp.png" width="50px"class="whatsapp_float_btn"/></a>
      </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>

</div>
</body>
</html>
